# PRD: Subah Geet (Scheduled Hindi Sadabahar Auto Player)

## 1. One line summary
App jo roz subah fixed time par khud jaagta hai (phone locked ho tab bhi), YouTube khol kar Hindi sadabahar gaana search karke play kar deta hai, bina root ke.

## 2. Goal
User ko subah manually kuch nahi karna — schedule set karega ek baar, uske baad har din wahi time par ek random Hindi sadabahar gaana khud baj jayega.

## 3. Core user flow
1. User app kholta hai, ek baar time set karta hai (e.g. 6:30 AM) — daily repeat.
2. User "song source" set karta hai:
   - **Mode A — My List**: khud gaano ke naam add karta hai (e.g. "Lag Ja Gale", "Chaudhvin Ka Chand"). App is list se random ek uthayega.
   - **Mode B — Auto Query**: app khud random search query banata hai list of templates se (e.g. "purane hindi gaane 1960s", "hindi sadabahar geet"). Random era/mood pick karke query banata hai.
   - User dono mode ke beech switch kar sakta hai settings me.
3. Scheduled time par:
   - App background me jaagta hai (phone locked ho ya na ho).
   - Screen wake hoti hai, ek full-screen "Good Morning" alarm-style screen dikhti hai 2-3 second ke liye.
   - YouTube app open hota hai selected/generated search query ke saath.
   - Search result me se pehla valid video automatically play hota hai.
4. User chahe to snooze/skip/stop kar sakta hai us screen se.

## 4. Kya possible hai bina root ke (verified constraints)

| Feature | Status | Kaise |
|---|---|---|
| Fixed daily time par app trigger | ✅ Possible | `AlarmManager.setExactAndAllowWhileIdle()` — Doze mode me bhi chalega |
| Phone locked hote hue bhi trigger | ✅ Possible | Full-screen intent notification (jaise incoming call/alarm apps) — `USE_FULL_SCREEN_INTENT` permission |
| Screen wake karna | ✅ Possible | `PowerManager.WakeLock` + `FLAG_SHOW_WHEN_LOCKED` + `FLAG_TURN_SCREEN_ON` on Activity |
| YouTube app ko search query ke saath khol na | ✅ Possible | Implicit `Intent` with YouTube search URI (`vnd.youtube:results?q=...` ya web search intent) |
| YouTube me automatically pehla result play karna | ⚠️ Limited | YouTube app ke andar hum click simulate nahi kar sakte bina Accessibility Service ke. Do options: <br>**(a)** Accessibility Service use karke YouTube UI par "pehla result" tap simulate karna — kaam karta hai par YouTube UI change hone par tootne ka risk hai.<br>**(b)** YouTube's deep link agar direct video ID pata ho to seedha play ho sakta hai — lekin "random search se pehla result" ke liye ye kaam nahi karta bina result list padhe. |
| Truly random song without any list | ❌ Not directly possible | YouTube koi public "random song" API nahi deta apps ko. Hum sirf apna curated list ya randomized search query bana sakte hain — result YouTube ka algorithm decide karta hai |
| Background reliability | ⚠️ Device dependent | Motorola/Moto G85 stock Android battery optimization apps ko background me kill kar sakta hai. User ko "battery optimization off" karna padega is app ke liye — ye PRD me ek onboarding step hoga |
| YouTube Premium/background play | N/A | Ye feature YouTube app ko foreground me laake play karta hai, background audio-only nahi (bina premium background play ke) |

**Important reality check jo user ko pata hona chahiye:**
- Accessibility Service wala part (auto-click first result) sabse fragile hai — YouTube apna UI update karta rehta hai, isliye kabhi kabhi break ho sakta hai. Isko maintain karna padega.
- Agar Accessibility Service use nahi karna (kyunki Play Store policy strict hai is par, aur sideload app me bhi user ko manually permission on karni padegi), toh fallback: app search karke YouTube khol dega, user ko khud ek tap karna padega pehla video play karne ke liye. Ye zyada reliable hai.

## 5. Recommended approach (decision needed from user)

**Option 1 — Semi-auto (recommended, zyada reliable)**
App search query ke saath YouTube kholta hai + screen wake karta hai. User ek tap karta hai video play karne ke liye. Accessibility Service nahi chahiye.

**Option 2 — Full-auto (Accessibility Service based)**
App khud pehla result tap kar deta hai. Zero manual action chahiye but fragile & permission-heavy (user ko Settings > Accessibility me manually enable karna padega, kyunki ye sideloaded app hoga).

## 6. Tech stack
- **Language**: Kotlin
- **UI**: Jetpack Compose (clean, modern, minimal — Material 3)
- **Scheduling**: AlarmManager + BroadcastReceiver (WorkManager exact-time ke liye reliable nahi hai, isliye AlarmManager sahi choice)
- **Wake/Lock-screen UI**: Activity with `FLAG_SHOW_WHEN_LOCKED` + `FLAG_TURN_SCREEN_ON` (modern replacement of deprecated `FLAG_DISMISS_KEYGUARD`)
- **YouTube launch**: Implicit Intent (`Intent.ACTION_VIEW` with `vnd.youtube:` or web fallback)
- **Optional Accessibility Service**: for Option 2 only
- **Local storage**: DataStore (Preferences) for song list + settings — no backend needed
- **Min SDK**: 26+ (Moto G85 ships Android 14, so safe to target modern APIs)

## 7. Screens (MVP)
1. **Home** — current schedule, next trigger time, quick on/off toggle
2. **Set Time** — time picker, repeat days
3. **Song Source** — toggle Mode A/B, manage list (add/remove songs) or manage query templates
4. **Wake Screen** — full-screen alarm-style UI: "Good Morning 🎵", song name, Play now / Snooze 10 min / Stop
5. **Settings** — battery optimization reminder, Accessibility toggle (if Option 2), about

## 8. Permissions needed
- `SCHEDULE_EXACT_ALARM` (Android 12+)
- `USE_FULL_SCREEN_INTENT`
- `POST_NOTIFICATIONS`
- `RECEIVE_BOOT_COMPLETED` (schedule survive reboot)
- Accessibility Service permission — only if Option 2 chosen

## 9. Out of scope for v1
- Actual audio-only background playback (needs YouTube Premium or a different audio-extraction approach, which violates YouTube ToS — not building this)
- Cloud sync / multi-device
- Playlist management beyond simple text list

## 10. Finalized decision
**Option 2 — Full-auto (Accessibility Service based) confirmed for v1.**
App khud YouTube UI padhega aur pehla valid video result tap karega — zero manual action user se. User ko ek baar Settings > Accessibility me app enable karni hogi (sideload app hai, Play Store se nahi).

Isse implementation me ye add hota hai:
- `AccessibilityService` subclass jo YouTube search results screen ke node tree ko scan karega
- Video result identify karne ka logic (view ID / content-description based — YouTube app version ke hisaab se badal sakta hai, isliye ek fallback bhi rakhenge: agar 6 second me result na mile to semi-auto mode par gir jayega, taaki app pura stuck na ho)
- Onboarding screen jo user ko Accessibility Settings tak deep-link kare pehli baar app open karne par
