# Subah Geet

Har subah scheduled time par phone khud jaagta hai, YouTube khol ke Hindi
sadabahar gaana search karta hai, aur pehla result auto play kar deta hai.
Bina root ke, Moto G85 (ya kisi bhi Android 8.0+ device) ke liye.

## Build karna

1. Android Studio (Koala ya naya) me `SubahGeet` folder open karo.
2. Gradle sync hone do (internet chahiye first time).
3. `Run` dabao, ya `Build > Build APK(s)` se seedha APK nikalo.
4. APK phone me install karo (Unknown sources allow karna padega, kyunki
   Play Store se nahi hai).

## Pehli baar setup (app install hone ke baad)

1. App kholo, time set karo, aur "My list" ya "Auto query" mode chuno.
2. Toggle on karo daily schedule.
3. **Auto Play permission** card me "Open Accessibility settings" dabao,
   list me "Subah Geet" dhoondo, aur enable karo. Ye step manual hai kyunki
   app Play Store se nahi hai — Android is permission ko extra suraksha se
   deta hai.
4. Battery optimization: Settings > Apps > Subah Geet > Battery > "Unrestricted"
   karo. Moto G85 ka stock battery manager warna is app ko background me
   kill kar sakta hai aur alarm miss ho sakta hai.
5. Pehli baar exact alarm permission bhi maang sakta hai Android
   (Settings > Apps > Special access > Alarms & reminders) — allow karo.

## Kaise kaam karta hai (short version)

- `AlarmManager` exact time par ek `BroadcastReceiver` fire karta hai, phone
  Doze me ho tab bhi.
- Ek full-screen Activity lock screen ke upar aati hai (jaise alarm clock
  app), 2 second dikhti hai, phir YouTube ko search intent ke saath khol
  deti hai.
- Ek `AccessibilityService` YouTube ki window ko padh ke pehla video result
  dhoondta hai aur tap simulate karta hai — 6 second ke andar. Agar na mile,
  automatically give up kar deta hai aur user manually tap kar sakta hai.

## Jaani-maani limitations (PRD me bhi likhi hain)

- **Accessibility auto-tap fragile hai.** YouTube apna UI update karta rehta
  hai, isliye kabhi kabhi first-result detection fail ho sakta hai. Isi liye
  6-second timeout ke baad app khud semi-auto (manual tap) par gir jaata hai
  — ye crash nahi, planned fallback hai.
- **Truly random song koi API nahi deta.** "My list" mode me tumhari list se
  random pick hota hai; "Auto query" mode me random search query banti hai
  (singer/era/mood combinations se) — actual video YouTube ka algorithm
  decide karta hai.
- **Background reliability device par depend karta hai.** Battery
  optimization off na ho to Motorola ka background killer isse rok sakta
  hai — README ke setup steps me ye cover kiya hai.
- Ye sideload APK hai, Play Store policy iski wajah se strict nahi hai, par
  isका matlab hai Accessibility permission manually enable karni padegi
  har baar app fresh install hone par.

## Project structure

```
app/src/main/java/com/alexcyberx/subahgeet/
  MainActivity.kt              - Home screen: schedule, song source, settings
  WakeScreenActivity.kt        - Lock-screen-style wake UI + YouTube launch
  alarm/AlarmScheduler.kt      - Exact alarm scheduling logic
  alarm/AlarmReceiver.kt       - Fires on schedule, launches wake screen
  alarm/BootReceiver.kt        - Restores schedule after reboot
  accessibility/YoutubeAutoPlayService.kt - Auto-taps first YouTube result
  data/SongRepository.kt       - DataStore-backed settings + song list
  ui/theme/                    - Compose theme (sunrise palette)
```
