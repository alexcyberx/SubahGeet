package com.alexcyberx.subahgeet.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

/**
 * Schedules the single next trigger for the morning song alarm.
 * Each firing reschedules itself for the next matching day (see AlarmReceiver),
 * since AlarmManager has no built-in "repeat on these weekdays" primitive
 * for exact alarms.
 */
object AlarmScheduler {

    private const val REQUEST_CODE = 1001

    fun schedule(context: Context, hour: Int, minute: Int, repeatDays: Set<String>) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = nextTriggerTimeMillis(hour, minute, repeatDays)
        if (triggerAt == null) return // no days selected, nothing to schedule

        val pendingIntent = buildPendingIntent(context)

        if (alarmManager.canScheduleExactAlarms()) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAt,
                pendingIntent
            )
        } else {
            // Fallback: inexact alarm, may drift a few minutes under Doze.
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAt,
                pendingIntent
            )
        }
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(buildPendingIntent(context))
    }

    private fun buildPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java)
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /**
     * Calendar day-of-week is 1=Sunday..7=Saturday, matching the string keys
     * we store in DataStore's repeatDays set.
     */
    private fun nextTriggerTimeMillis(hour: Int, minute: Int, repeatDays: Set<String>): Long? {
        if (repeatDays.isEmpty()) return null

        val now = Calendar.getInstance()
        for (dayOffset in 0..7) {
            val candidate = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, dayOffset)
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val dayKey = candidate.get(Calendar.DAY_OF_WEEK).toString()
            if (dayKey in repeatDays && candidate.timeInMillis > now.timeInMillis) {
                return candidate.timeInMillis
            }
        }
        return null
    }
}
