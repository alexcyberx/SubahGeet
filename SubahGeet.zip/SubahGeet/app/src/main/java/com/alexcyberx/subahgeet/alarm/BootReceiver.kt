package com.alexcyberx.subahgeet.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.alexcyberx.subahgeet.data.SongRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val repo = SongRepository(context.applicationContext)
        CoroutineScope(Dispatchers.Default).launch {
            val enabled = repo.alarmEnabled.first()
            if (!enabled) return@launch

            val hour = repo.alarmHour.first()
            val minute = repo.alarmMinute.first()
            val days = repo.repeatDays.first()
            AlarmScheduler.schedule(context.applicationContext, hour, minute, days)
            ScheduleForegroundService.start(context.applicationContext)
        }
    }
}
