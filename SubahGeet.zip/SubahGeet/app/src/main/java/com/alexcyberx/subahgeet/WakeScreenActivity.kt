package com.alexcyberx.subahgeet

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alexcyberx.subahgeet.accessibility.YoutubeAutoPlayService
import com.alexcyberx.subahgeet.ui.theme.SubahGeetTheme

class WakeScreenActivity : ComponentActivity() {

    companion object {
        const val EXTRA_QUERY = "extra_query"
        private const val AUTO_LAUNCH_DELAY_MS = 2200L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLockedFlags()

        val query = intent.getStringExtra(EXTRA_QUERY).orEmpty().ifBlank {
            "hindi sadabahar geet"
        }

        setContent {
            SubahGeetTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    WakeScreenContent(query)
                }
            }
        }

        // Give the "Good Morning" screen a couple of seconds to be visible,
        // then hand off to YouTube. The Accessibility Service is armed just
        // before launch so it starts watching for the results screen.
        Handler(Looper.getMainLooper()).postDelayed({
            launchYoutubeSearch(query)
        }, AUTO_LAUNCH_DELAY_MS)
    }

    private fun setShowWhenLockedFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
    }

    private fun launchYoutubeSearch(query: String) {
        YoutubeAutoPlayService.pendingAutoPlay = true

        val encoded = Uri.encode(query)
        val youtubeUri = Uri.parse("vnd.youtube:results?q=$encoded")
        val intent = Intent(Intent.ACTION_VIEW, youtubeUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.google.android.youtube")
        }

        try {
            startActivity(intent)
        } catch (e: Exception) {
            // YouTube app not present or intent rejected: fall back to a web search,
            // which at least gets the user to results manually.
            val webIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=$encoded")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(webIntent)
        }

        finish()
    }
}

@Composable
private fun WakeScreenContent(query: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Filled.MusicNote,
            contentDescription = null,
            modifier = Modifier.padding(bottom = 16.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Good Morning",
            fontSize = 28.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = query,
            fontSize = 16.sp,
            modifier = Modifier.padding(top = 8.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
