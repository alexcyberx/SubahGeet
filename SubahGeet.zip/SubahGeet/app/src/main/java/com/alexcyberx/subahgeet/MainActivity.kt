package com.alexcyberx.subahgeet

import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.alexcyberx.subahgeet.alarm.AlarmScheduler
import com.alexcyberx.subahgeet.data.SongMode
import com.alexcyberx.subahgeet.data.SongRepository
import com.alexcyberx.subahgeet.ui.theme.SubahGeetTheme
import kotlinx.coroutines.launch

private val dayLabels = listOf("1" to "Sun", "2" to "Mon", "3" to "Tue", "4" to "Wed", "5" to "Thu", "6" to "Fri", "7" to "Sat")

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = androidx.core.content.ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            SubahGeetTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SubahGeetApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubahGeetApp() {
    val context = LocalContext.current
    val repo = remember { SongRepository(context) }
    val scope = rememberCoroutineScope()

    val hour by repo.alarmHour.collectAsStateSafe(6)
    val minute by repo.alarmMinute.collectAsStateSafe(30)
    val enabled by repo.alarmEnabled.collectAsStateSafe(false)
    val repeatDays by repo.repeatDays.collectAsStateSafe(setOf("1", "2", "3", "4", "5", "6", "7"))
    val songMode by repo.songMode.collectAsStateSafe(SongMode.MY_LIST)
    val songList by repo.songList.collectAsStateSafe(SongRepository.defaultSongs)
    val accessibilityOnboarded by repo.accessibilityOnboarded.collectAsStateSafe(false)

    var newSongText by remember { mutableStateOf("") }
    var hasExactAlarm by remember { mutableStateOf(hasExactAlarmPermission(context)) }

    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                hasExactAlarm = hasExactAlarmPermission(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Subah Geet") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ScheduleCard(
                    hour = hour,
                    minute = minute,
                    enabled = enabled,
                    repeatDays = repeatDays,
                    onEnabledChange = { value ->
                        scope.launch {
                            repo.setAlarmEnabled(value)
                            if (value) {
                                if (!hasExactAlarmPermission(context)) {
                                    openExactAlarmSettings(context)
                                }
                                AlarmScheduler.schedule(context, hour, minute, repeatDays)
                            } else {
                                AlarmScheduler.cancel(context)
                            }
                        }
                    },
                    onTimeChange = { h, m ->
                        scope.launch {
                            repo.setAlarmTime(h, m)
                            if (enabled) {
                                AlarmScheduler.schedule(context, h, m, repeatDays)
                            }
                        }
                    },
                    onDaysChange = { days ->
                        scope.launch {
                            repo.setRepeatDays(days)
                            if (enabled) {
                                AlarmScheduler.schedule(context, hour, minute, days)
                            }
                        }
                    }
                )
            }

            item {
                SongSourceCard(
                    mode = songMode,
                    songList = songList,
                    newSongText = newSongText,
                    onModeChange = { scope.launch { repo.setSongMode(it) } },
                    onNewSongTextChange = { newSongText = it },
                    onAddSong = {
                        if (newSongText.isNotBlank()) {
                            scope.launch {
                                repo.addSong(newSongText.trim())
                                newSongText = ""
                            }
                        }
                    },
                    onRemoveSong = { song -> scope.launch { repo.removeSong(song) } }
                )
            }

            item {
                AccessibilityCard(
                    onboarded = accessibilityOnboarded,
                    onOpenSettings = {
                        scope.launch { repo.setAccessibilityOnboarded(true) }
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        context.startActivity(intent)
                    }
                )
            }

            item {
                ReliabilityCard(
                    hasExactAlarm = hasExactAlarm,
                    onOpenExactAlarmSettings = { openExactAlarmSettings(context) },
                    onOpenBatterySettings = { openBatterySettings(context) }
                )
            }
        }
    }
}

@Composable
private fun ReliabilityCard(
    hasExactAlarm: Boolean,
    onOpenExactAlarmSettings: () -> Unit,
    onOpenBatterySettings: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Reliability checks", style = MaterialTheme.typography.titleLarge)
            Text(
                text = "These two settings decide whether the alarm actually fires on time. Without them, the schedule can silently fail on some phones.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (hasExactAlarm) "Exact alarms: allowed" else "Exact alarms: not allowed",
                    style = MaterialTheme.typography.bodyLarge
                )
                if (!hasExactAlarm) {
                    TextButton(onClick = onOpenExactAlarmSettings) { Text("Fix") }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Battery: set to Unrestricted",
                    style = MaterialTheme.typography.bodyLarge
                )
                TextButton(onClick = onOpenBatterySettings) { Text("Open") }
            }
        }
    }
}

private fun hasExactAlarmPermission(context: android.content.Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val alarmManager = context.getSystemService(android.content.Context.ALARM_SERVICE) as AlarmManager
        alarmManager.canScheduleExactAlarms()
    } else {
        true
    }
}

private fun openExactAlarmSettings(context: android.content.Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
            data = Uri.parse("package:${context.packageName}")
        }
        context.startActivity(intent)
    }
}

private fun openBatterySettings(context: android.content.Context) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = Uri.parse("package:${context.packageName}")
    }
    context.startActivity(intent)
}

@Composable
private fun ScheduleCard(
    hour: Int,
    minute: Int,
    enabled: Boolean,
    repeatDays: Set<String>,
    onEnabledChange: (Boolean) -> Unit,
    onTimeChange: (Int, Int) -> Unit,
    onDaysChange: (Set<String>) -> Unit
) {
    var showPicker by remember { mutableStateOf(false) }

    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors()) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Daily schedule", style = MaterialTheme.typography.titleLarge)
                    Text(
                        text = String.format("%02d:%02d", hour, minute),
                        style = MaterialTheme.typography.headlineLarge,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Switch(checked = enabled, onCheckedChange = onEnabledChange)
            }

            TextButton(onClick = { showPicker = true }, modifier = Modifier.padding(top = 8.dp)) {
                Text("Change time")
            }

            Text(
                text = "Repeat on",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                dayLabels.forEach { (key, label) ->
                    FilterChip(
                        selected = key in repeatDays,
                        onClick = {
                            val updated = if (key in repeatDays) repeatDays - key else repeatDays + key
                            onDaysChange(updated)
                        },
                        label = { Text(label) }
                    )
                }
            }
        }
    }

    if (showPicker) {
        TimePickerDialog(
            initialHour = hour,
            initialMinute = minute,
            onDismiss = { showPicker = false },
            onConfirm = { h, m ->
                onTimeChange(h, m)
                showPicker = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimePickerDialog(
    initialHour: Int,
    initialMinute: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int, Int) -> Unit
) {
    val state = rememberTimePickerState(initialHour = initialHour, initialMinute = initialMinute, is24Hour = true)
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onConfirm(state.hour, state.minute) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        text = { TimePicker(state = state) }
    )
}

@Composable
private fun SongSourceCard(
    mode: SongMode,
    songList: Set<String>,
    newSongText: String,
    onModeChange: (SongMode) -> Unit,
    onNewSongTextChange: (String) -> Unit,
    onAddSong: () -> Unit,
    onRemoveSong: (String) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Song source", style = MaterialTheme.typography.titleLarge)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = mode == SongMode.MY_LIST,
                    onClick = { onModeChange(SongMode.MY_LIST) },
                    label = { Text("My list") }
                )
                FilterChip(
                    selected = mode == SongMode.AUTO_QUERY,
                    onClick = { onModeChange(SongMode.AUTO_QUERY) },
                    label = { Text("Auto query") }
                )
            }

            if (mode == SongMode.MY_LIST) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newSongText,
                        onValueChange = onNewSongTextChange,
                        label = { Text("Add a song name") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    IconButton(onClick = onAddSong) {
                        Icon(Icons.Filled.Add, contentDescription = "Add song")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                songList.forEach { song ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(song, style = MaterialTheme.typography.bodyLarge)
                        IconButton(onClick = { onRemoveSong(song) }) {
                            Icon(Icons.Filled.Close, contentDescription = "Remove $song")
                        }
                    }
                    Divider()
                }
            } else {
                Text(
                    text = "A random era/mood search (e.g. Kishore Kumar hindi sadabahar geet) will be used each morning.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }
        }
    }
}

@Composable
private fun AccessibilityCard(
    onboarded: Boolean,
    onOpenSettings: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Auto play permission", style = MaterialTheme.typography.titleLarge)
            Text(
                text = "Enable Subah Geet under Settings > Accessibility so it can tap the first video for you automatically. Without this, YouTube will still open and search, but you'll need to tap the video yourself.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
            )
            Button(onClick = onOpenSettings) {
                Text(if (onboarded) "Open Accessibility settings again" else "Open Accessibility settings")
            }
        }
    }
}

// Small helper to collect a Flow<T> as Compose state without boilerplate at each call site.
@Composable
private fun <T> kotlinx.coroutines.flow.Flow<T>.collectAsStateSafe(initial: T) =
    this.collectAsStateWithLifecycleSafe(initial)

@Composable
private fun <T> kotlinx.coroutines.flow.Flow<T>.collectAsStateWithLifecycleSafe(initial: T): androidx.compose.runtime.State<T> {
    val state = remember { mutableStateOf(initial) }
    LaunchedEffect(this) {
        this@collectAsStateWithLifecycleSafe.collect { value -> state.value = value }
    }
    return state
}
