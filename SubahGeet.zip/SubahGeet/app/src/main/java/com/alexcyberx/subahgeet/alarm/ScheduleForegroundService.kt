package com.alexcyberx.subahgeet.alarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.alexcyberx.subahgeet.MainActivity
import com.alexcyberx.subahgeet.WakeScreenActivity
import com.alexcyberx.subahgeet.data.SongRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Runs as a foreground service whenever the schedule is enabled. AlarmManager
 * broadcasts alone were found to be silently dropped on this device's stock
 * battery/Doze management once the screen was locked for a while, even with
 * exact-alarm permission granted. A foreground service is exempt from Doze
 * and App Standby, so it stays alive to fire the wake screen reliably, and
 * still calls into AlarmScheduler as a backup path.
 */
class ScheduleForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var countDownTimer: CountDownTimer? = null
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        private const val CHANNEL_ID = "subah_geet_schedule"
        private const val NOTIFICATION_ID = 42
        const val ACTION_START = "com.alexcyberx.subahgeet.action.START_SCHEDULE"
        const val ACTION_STOP = "com.alexcyberx.subahgeet.action.STOP_SCHEDULE"

        fun start(context: Context) {
            val intent = Intent(context, ScheduleForegroundService::class.java).apply {
                action = ACTION_START
            }
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, ScheduleForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildNotification("Waiting for your scheduled time"))
                scheduleNextCheck()
            }
        }
        return START_STICKY
    }

    private fun scheduleNextCheck() {
        countDownTimer?.cancel()
        val repo = SongRepository(applicationContext)

        scope.launch {
            val enabled = repo.alarmEnabled.first()
            if (!enabled) {
                stopSelf()
                return@launch
            }

            val hour = repo.alarmHour.first()
            val minute = repo.alarmMinute.first()
            val days = repo.repeatDays.first()

            val target = nextTargetMillis(hour, minute, days) ?: run {
                stopSelf()
                return@launch
            }

            val delay = target - System.currentTimeMillis()

            // Also keep AlarmManager scheduled as a secondary path.
            AlarmScheduler.schedule(applicationContext, hour, minute, days)

            if (delay <= 0) {
                fireWakeScreen()
                return@launch
            }

            // CountDownTimer callbacks run on the main looper by default;
            // it's created here off the main thread but that's fine since
            // we only start/cancel it, we don't touch views.
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                val tickInterval = delay.coerceAtMost(5 * 60_000L)
                countDownTimer = object : CountDownTimer(delay, tickInterval) {
                    override fun onTick(millisUntilFinished: Long) {
                        // Periodically refresh the notification so Android
                        // treats the service as actively working, not idle.
                        val minutesLeft = millisUntilFinished / 60000
                        val label = if (minutesLeft < 60) {
                            "Song plays in $minutesLeft min"
                        } else {
                            "Song plays in ${minutesLeft / 60}h ${minutesLeft % 60}m"
                        }
                        updateNotification(label)
                    }

                    override fun onFinish() {
                        fireWakeScreen()
                    }
                }.start()
            }
        }
    }

    private fun fireWakeScreen() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        val lock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "SubahGeet:ServiceWakeLock"
        )
        lock.acquire(20_000L)
        wakeLock = lock

        scope.launch {
            val repo = SongRepository(applicationContext)
            val query = repo.pickQueryForToday()

            val wakeIntent = Intent(applicationContext, WakeScreenActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(WakeScreenActivity.EXTRA_QUERY, query)
            }
            applicationContext.startActivity(wakeIntent)

            if (lock.isHeld) lock.release()

            // Re-arm for the next matching day.
            scheduleNextCheck()
        }
    }

    private fun nextTargetMillis(hour: Int, minute: Int, days: Set<String>): Long? {
        if (days.isEmpty()) return null
        val now = Calendar.getInstance()
        for (dayOffset in 0..7) {
            val candidate = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, dayOffset)
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val dayKey = candidate.get(Calendar.DAY_OF_WEEK).toString()
            if (dayKey in days && candidate.timeInMillis > now.timeInMillis) {
                return candidate.timeInMillis
            }
        }
        return null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Morning schedule",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the morning song schedule running reliably"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openAppIntent = Intent(applicationContext, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            applicationContext, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle("Subah Geet is scheduled")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        countDownTimer?.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
