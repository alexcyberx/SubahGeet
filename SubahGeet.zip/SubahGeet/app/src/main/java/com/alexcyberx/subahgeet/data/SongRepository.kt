package com.alexcyberx.subahgeet.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "subah_geet_prefs")

enum class SongMode { MY_LIST, AUTO_QUERY }

// Query templates used when the user picks Auto Query mode.
// These combine an era/mood fragment with a fixed "hindi sadabahar" anchor
// so the search stays on-genre while still varying.
object QueryTemplates {
    private val eras = listOf(
        "1950s", "1960s", "1970s", "1980s", "90s"
    )
    private val moods = listOf(
        "sadabahar geet", "purane gaane", "evergreen hits", "old is gold", "classic gaane"
    )
    private val singers = listOf(
        "Lata Mangeshkar", "Kishore Kumar", "Mohammed Rafi", "Mukesh", "Asha Bhosle"
    )

    fun randomQuery(): String {
        val useSinger = (0..1).random() == 0
        return if (useSinger) {
            "${singers.random()} hindi ${moods.random()}"
        } else {
            "hindi ${moods.random()} ${eras.random()}"
        }
    }
}

object PrefKeys {
    val ALARM_HOUR = intPreferencesKey("alarm_hour")
    val ALARM_MINUTE = intPreferencesKey("alarm_minute")
    val ALARM_ENABLED = booleanPreferencesKey("alarm_enabled")
    val REPEAT_DAYS = stringSetPreferencesKey("repeat_days") // "1".."7", Sunday=1
    val SONG_MODE = stringPreferencesKey("song_mode")
    val SONG_LIST = stringSetPreferencesKey("song_list")
    val ACCESSIBILITY_ONBOARDED = booleanPreferencesKey("accessibility_onboarded")
}

class SongRepository(private val context: Context) {

    val alarmHour: Flow<Int> = context.dataStore.data.map { it[PrefKeys.ALARM_HOUR] ?: 6 }
    val alarmMinute: Flow<Int> = context.dataStore.data.map { it[PrefKeys.ALARM_MINUTE] ?: 30 }
    val alarmEnabled: Flow<Boolean> = context.dataStore.data.map { it[PrefKeys.ALARM_ENABLED] ?: false }
    val repeatDays: Flow<Set<String>> = context.dataStore.data.map {
        it[PrefKeys.REPEAT_DAYS] ?: setOf("1", "2", "3", "4", "5", "6", "7")
    }
    val songMode: Flow<SongMode> = context.dataStore.data.map {
        when (it[PrefKeys.SONG_MODE]) {
            SongMode.AUTO_QUERY.name -> SongMode.AUTO_QUERY
            else -> SongMode.MY_LIST
        }
    }
    val songList: Flow<Set<String>> = context.dataStore.data.map {
        it[PrefKeys.SONG_LIST] ?: defaultSongs
    }
    val accessibilityOnboarded: Flow<Boolean> = context.dataStore.data.map {
        it[PrefKeys.ACCESSIBILITY_ONBOARDED] ?: false
    }

    suspend fun setAlarmTime(hour: Int, minute: Int) {
        context.dataStore.edit {
            it[PrefKeys.ALARM_HOUR] = hour
            it[PrefKeys.ALARM_MINUTE] = minute
        }
    }

    suspend fun setAlarmEnabled(enabled: Boolean) {
        context.dataStore.edit { it[PrefKeys.ALARM_ENABLED] = enabled }
    }

    suspend fun setRepeatDays(days: Set<String>) {
        context.dataStore.edit { it[PrefKeys.REPEAT_DAYS] = days }
    }

    suspend fun setSongMode(mode: SongMode) {
        context.dataStore.edit { it[PrefKeys.SONG_MODE] = mode.name }
    }

    suspend fun addSong(name: String) {
        context.dataStore.edit {
            val current = it[PrefKeys.SONG_LIST] ?: defaultSongs
            it[PrefKeys.SONG_LIST] = current + name
        }
    }

    suspend fun removeSong(name: String) {
        context.dataStore.edit {
            val current = it[PrefKeys.SONG_LIST] ?: defaultSongs
            it[PrefKeys.SONG_LIST] = current - name
        }
    }

    suspend fun setAccessibilityOnboarded(value: Boolean) {
        context.dataStore.edit { it[PrefKeys.ACCESSIBILITY_ONBOARDED] = value }
    }

    /** Picks the search query to use right now, based on current mode. Suspends to read DataStore once. */
    suspend fun pickQueryForToday(): String {
        val mode = songMode.first()
        return if (mode == SongMode.AUTO_QUERY) {
            QueryTemplates.randomQuery()
        } else {
            val list = songList.first()
            if (list.isEmpty()) QueryTemplates.randomQuery() else list.random()
        }
    }

    companion object {
        val defaultSongs = setOf(
            "Lag Ja Gale",
            "Chaudhvin Ka Chand",
            "Mere Sapno Ki Rani",
            "Pal Pal Dil Ke Paas",
            "Yeh Sham Mastani"
        )
    }
}
