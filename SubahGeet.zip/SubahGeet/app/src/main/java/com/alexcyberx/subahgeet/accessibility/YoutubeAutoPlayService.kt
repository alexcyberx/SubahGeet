package com.alexcyberx.subahgeet.accessibility

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Watches YouTube's window tree after we've launched a search intent, finds the
 * first tappable video result in the results list, and clicks it.
 *
 * YouTube does not expose stable view IDs for third-party automation, so this
 * relies on structural heuristics (row containers under a RecyclerView-like
 * results list) that can break when YouTube changes its UI. If no match is
 * found within TIMEOUT_MS, this backs off entirely and leaves the app in
 * "semi-auto" state — the search results stay open and the user taps manually.
 * This is the fallback described in the PRD; it is intentional, not a bug.
 */
class YoutubeAutoPlayService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var attemptRunnable: Runnable? = null
    private var attemptsMade = 0
    private var armed = false

    companion object {
        private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        private const val TIMEOUT_MS = 3000L
        private const val RETRY_INTERVAL_MS = 300L
        private const val MAX_ATTEMPTS = (TIMEOUT_MS / RETRY_INTERVAL_MS).toInt()

        @Volatile
        var pendingAutoPlay = false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName != YOUTUBE_PACKAGE) return
        if (!pendingAutoPlay) return

        if (!armed) {
            armed = true
            attemptsMade = 0
            scheduleAttempt()
        }
    }

    private fun scheduleAttempt() {
        attemptRunnable?.let { handler.removeCallbacks(it) }
        val runnable = Runnable {
            val success = tryClickFirstResult()
            attemptsMade++
            if (success) {
                stopAutoPlayAttempt()
            } else if (attemptsMade < MAX_ATTEMPTS) {
                scheduleAttempt()
            } else {
                // Timed out: give up automatically, user finishes it manually.
                stopAutoPlayAttempt()
            }
        }
        attemptRunnable = runnable
        handler.postDelayed(runnable, RETRY_INTERVAL_MS)
    }

    private fun stopAutoPlayAttempt() {
        pendingAutoPlay = false
        armed = false
        attemptRunnable?.let { handler.removeCallbacks(it) }
        attemptRunnable = null
    }

    /**
     * Heuristic: look for the first node in the active window that looks like
     * a video result thumbnail/title and is clickable (or has a clickable
     * ancestor), then perform ACTION_CLICK on it.
     */
    private fun tryClickFirstResult(): Boolean {
        val root = rootInActiveWindow ?: return false
        val candidate = findFirstVideoResult(root)
        return if (candidate != null) {
            val clickable = findClickableSelfOrAncestor(candidate)
            clickable?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
        } else {
            false
        }
    }

    private fun findFirstVideoResult(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        // YouTube marks video thumbnails/titles with content descriptions or
        // resource ids containing "video" in most current versions. We check
        // both since resource-id availability differs by YouTube version.
        val resId = node.viewIdResourceName ?: ""
        val desc = node.contentDescription?.toString() ?: ""

        val looksLikeVideoResult =
            resId.contains("video_title", ignoreCase = true) ||
                resId.contains("thumbnail", ignoreCase = true) ||
                (desc.isNotBlank() && node.isClickable)

        if (looksLikeVideoResult) return node

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findFirstVideoResult(child)
            if (found != null) return found
        }
        return null
    }

    private fun findClickableSelfOrAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth < 6) {
            if (current.isClickable) return current
            current = current.parent
            depth++
        }
        return null
    }

    override fun onInterrupt() {
        stopAutoPlayAttempt()
    }
}
