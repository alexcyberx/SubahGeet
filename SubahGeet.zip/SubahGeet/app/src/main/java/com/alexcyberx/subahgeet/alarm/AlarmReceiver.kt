package com.alexcyberx.subahgeet.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Fires at the exact scheduled time via AlarmManager. All actual work
 * (picking a song, launching the wake screen, rescheduling) happens inside
 * AlarmTriggerService, started here as a short-lived foreground service.
 * Starting a foreground service from an AlarmManager broadcast is one of
 * the documented exemptions to Android 14+'s background-start restrictions,
 * so this hand-off is reliable even when the app hasn't been opened recently.
 */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmTriggerService.trigger(context.applicationContext)
    }
}
