package com.alexcyberx.subahgeet.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import com.alexcyberx.subahgeet.WakeScreenActivity
import com.alexcyberx.subahgeet.data.SongRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // Briefly wake the CPU so we reliably get through to starting the activity
        // before the system can doze again mid-broadcast.
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "SubahGeet:AlarmWakeLock"
        )
        wakeLock.acquire(20_000L)

        val repo = SongRepository(context.applicationContext)

        CoroutineScope(Dispatchers.Default).launch {
            try {
                val query = repo.pickQueryForToday()

                val wakeIntent = Intent(context, WakeScreenActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    putExtra(WakeScreenActivity.EXTRA_QUERY, query)
                }
                context.startActivity(wakeIntent)

                // Reschedule for the next matching day so the alarm keeps repeating.
                val hour = repo.alarmHour.first()
                val minute = repo.alarmMinute.first()
                val days = repo.repeatDays.first()
                AlarmScheduler.schedule(context.applicationContext, hour, minute, days)
            } finally {
                if (wakeLock.isHeld) wakeLock.release()
            }
        }
    }
}
