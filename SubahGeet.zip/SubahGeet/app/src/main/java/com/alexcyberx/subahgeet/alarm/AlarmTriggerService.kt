package com.alexcyberx.subahgeet.alarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.alexcyberx.subahgeet.WakeScreenActivity
import com.alexcyberx.subahgeet.data.SongRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * A short-lived foreground service started only at the exact moment the
 * alarm fires. It exists for a few seconds: just long enough to reliably
 * launch WakeScreenActivity over the lock screen, then it stops itself.
 *
 * This is deliberately NOT a long-running background service. An earlier
 * version tried to stay alive for hours (from the moment the schedule is
 * turned on until the next trigger) with a persistent "song plays in X min"
 * notification, and Android's background/Doze restrictions silently killed
 * or blocked it before it ever fired. Starting fresh, briefly, right at
 * trigger time — the same pattern alarm-clock apps use — avoids that class
 * of restriction entirely.
 */
class AlarmTriggerService : Service() {

    companion object {
        private const val CHANNEL_ID = "subah_geet_trigger"
        private const val NOTIFICATION_ID = 43

        fun trigger(context: Context) {
            val intent = Intent(context, AlarmTriggerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForeground(NOTIFICATION_ID, notification)
            }

            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "SubahGeet:TriggerWakeLock"
            )
            wakeLock.acquire(15_000L)

            CoroutineScope(Dispatchers.Default).launch {
                try {
                    val repo = SongRepository(applicationContext)
                    val query = repo.pickQueryForToday()

                    val wakeIntent = Intent(applicationContext, WakeScreenActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        putExtra(WakeScreenActivity.EXTRA_QUERY, query)
                    }
                    applicationContext.startActivity(wakeIntent)

                    // Reschedule the next occurrence so the alarm keeps repeating.
                    val hour = repo.alarmHour.first()
                    val minute = repo.alarmMinute.first()
                    val days = repo.repeatDays.first()
                    AlarmScheduler.schedule(applicationContext, hour, minute, days)
                } catch (e: Exception) {
                    android.util.Log.e("SubahGeet", "AlarmTriggerService work failed", e)
                } finally {
                    if (wakeLock.isHeld) wakeLock.release()
                    stopSelf()
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("SubahGeet", "AlarmTriggerService failed to start", e)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Morning alarm",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shown briefly while your morning song is starting"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle("Subah Geet")
            .setContentText("Starting your morning song")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
