package com.alexcyberx.subahgeet.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Sunrise-inspired palette: deep pre-dawn indigo background, warm amber accent
// for the "song about to play" moment. Chosen for a morning-alarm app rather
// than a generic Material default.
private val SunriseAmber = Color(0xFFF2A65A)
private val DawnIndigo = Color(0xFF1B1B2F)
private val DawnIndigoSurface = Color(0xFF23233A)
private val MorningCream = Color(0xFFFFF6EC)
private val DuskPlum = Color(0xFF6B4E71)

private val DarkColors = darkColorScheme(
    primary = SunriseAmber,
    onPrimary = DawnIndigo,
    background = DawnIndigo,
    onBackground = MorningCream,
    surface = DawnIndigoSurface,
    onSurface = MorningCream,
    onSurfaceVariant = Color(0xFFC9C2D6),
    secondary = DuskPlum
)

private val LightColors = lightColorScheme(
    primary = Color(0xFFB5651D),
    onPrimary = MorningCream,
    background = MorningCream,
    onBackground = DawnIndigo,
    surface = Color(0xFFFFFFFF),
    onSurface = DawnIndigo,
    onSurfaceVariant = Color(0xFF5C5468),
    secondary = DuskPlum
)

@Composable
fun SubahGeetTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = SubahGeetTypography,
        content = content
    )
}
